import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { initializeFirestore, getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import rawConfig from '../../firebase-applet-config.json';

/**
 * HARDCODED PERMANENT FIREBASE & FIRESTORE CONFIGURATION
 * Locked to project: gen-lang-client-0974110233
 * Database ID: ai-studio-remixremixercapo-3247d174-5bf6-4f3b-b152-647cbcc422fe
 * Even if this applet is remixed or cloned, this database connection and rules remain permanent.
 */
export const HARDCODED_FIREBASE_CONFIG = {
  projectId: 'gen-lang-client-0974110233',
  appId: '1:248224905900:web:c13bcbfc7804a1311f7d09',
  apiKey: 'AIzaSyC1WLKTpPLJAZrDtxt58hOuH29O1Y4c9NM',
  authDomain: 'gen-lang-client-0974110233.firebaseapp.com',
  firestoreDatabaseId: 'ai-studio-remixremixercapo-3247d174-5bf6-4f3b-b152-647cbcc422fe',
  storageBucket: 'gen-lang-client-0974110233.firebasestorage.app',
  messagingSenderId: '248224905900',
  measurementId: '',
  oAuthClientId: '248224905900-qqdkta2pd0p14t0bgrcriktvlhlte6f7.apps.googleusercontent.com',
  recaptchaSiteKey: ''
};

export const HARDCODED_DATABASE_ID = 'ai-studio-remixremixercapo-3247d174-5bf6-4f3b-b152-647cbcc422fe';

export const firebaseConfig = {
  ...HARDCODED_FIREBASE_CONFIG,
  ...(rawConfig && typeof rawConfig === 'object' ? rawConfig : {}),
  // Enforce permanent database and project lock
  firestoreDatabaseId: HARDCODED_DATABASE_ID,
  projectId: HARDCODED_FIREBASE_CONFIG.projectId,
  apiKey: HARDCODED_FIREBASE_CONFIG.apiKey,
  authDomain: HARDCODED_FIREBASE_CONFIG.authDomain,
  appId: HARDCODED_FIREBASE_CONFIG.appId,
  storageBucket: HARDCODED_FIREBASE_CONFIG.storageBucket
};

let app: FirebaseApp;
let db: Firestore;
let auth: Auth | null = null;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid ?? null,
      email: auth?.currentUser?.email ?? null,
      emailVerified: auth?.currentUser?.emailVerified ?? null,
      isAnonymous: auth?.currentUser?.isAnonymous ?? null,
      tenantId: auth?.currentUser?.tenantId ?? null,
      providerInfo: auth?.currentUser?.providerData?.map((provider) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn('Firestore Operation Notice: ', JSON.stringify(errInfo));
  return errInfo;
}

try {
  app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
  
  const firestoreSettings = {
    experimentalForceLongPolling: true,
  };

  try {
    db = initializeFirestore(app, firestoreSettings, HARDCODED_DATABASE_ID);
  } catch {
    db = getFirestore(app, HARDCODED_DATABASE_ID);
  }

  try {
    auth = getAuth(app);
  } catch (authInitErr) {
    console.warn('Auth initialization note:', authInitErr);
  }
} catch (error) {
  console.error('Firebase initialization error, executing recovery:', error);
  app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  try {
    const firestoreSettings = { experimentalForceLongPolling: true };
    try {
      db = initializeFirestore(app, firestoreSettings, HARDCODED_DATABASE_ID);
    } catch {
      db = getFirestore(app, HARDCODED_DATABASE_ID);
    }
  } catch {
    db = getFirestore(app, HARDCODED_DATABASE_ID);
  }
  try {
    auth = getAuth(app);
  } catch {
    auth = null;
  }
}

export { app, db, auth };
export default db;
